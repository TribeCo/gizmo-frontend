import React from "react";

const ProductCardGroup = async ({ token }) => {
	return <div>ProductCardGroup</div>;
};

export default ProductCardGroup;
