export const products = [
	{
		name: "اسپرسوساز نون مدل CM540 3D-GS",
		price: 18000,
		description: "product 1",
		badge: "تخفیف ویژه",
		discount: 10,
		image1:
			"https://s3-alpha-sig.figma.com/img/9cdd/cdda/5c9567f323a8d9d1b5ee609f833964b0?Expires=1708905600&Key-Pair-Id=APKAQ4GOSFWCVNEHN3O4&Signature=g80ILlqIo-A0UmAvki-2QH5mqfwcvCxUiSlEhVNxtioWunb9axF1ioG~41MwYML6pKxclyx8Mq~cxvEXkz0ldvo5VjlsAyX1GnAhpaxsCkHi0Eb9in8wnqtYkfVuk~j6ooWhLf~g7TgDGEaZsbsUcnm2WybW-BcA-PNanaT2FN48~zSYL8-0FTwoRGpgG5MGbtkGPzQN7vuhDsQ3DFHFYNl7UllKm3I7nGFW-ial1Y~AqiwDhD5eKA0c~s5UIPapxImZQgxLNDD3aO-a8ePEqqyc5z1fYNQIChDirt-gkpFvYTNLbJwOb8jHKc2d5KFKeWRDkTXXh1KR27BwXgSjEg__",
		image2:
			"https://s3-alpha-sig.figma.com/img/a95b/553d/07b7f8faa305d5e35585d3a62a1ffdd3?Expires=1708905600&Key-Pair-Id=APKAQ4GOSFWCVNEHN3O4&Signature=TPuYorwotzw5LdL~N-zqbyHZOzvIqAyVvC4SntCNrY53oJigDlOEsgDDF-FPSgOMoqIYwsNvK1VOIT1udKu92q-vDl9Tml6XatSbZ-hZWEQmj4dJHpNyfYRdyqcGTqApj1J4qayKi~XXx-WmYtJA-A9BwFVNYwXRQTP9p71np1NYjE5pGwTSAhD5q1xkEZeS6c3zbPO8lDFWGHrWRRiXtjkklRLvt7gL1Vf663jc2qbWZ6Djzn2eC6sSgUSnsyPAdYfUflowxTHFgxpeqwSFwTWHzgOryTtRBor-2yMIHA-SgvZpi4PFS03HCED3c3ifDYAm28AITeJmAhQG6PovsQ__",
	},
	{
		name: "اسپرسوساز نون مدل CM540 3D-GS",
		price: 18000,
		description: "product 2",
		badge: "10%",
		discount: 10,
		image1: "",
		image2: "",
	},
	{
		name: "اسپرسوساز نون مدل CM540 3D-GS",
		price: 18000,
		description: "product 3",
		badge: "جدید",
		discount: 0,
		image1:
			"https://s3-alpha-sig.figma.com/img/9cdd/cdda/5c9567f323a8d9d1b5ee609f833964b0?Expires=1708905600&Key-Pair-Id=APKAQ4GOSFWCVNEHN3O4&Signature=g80ILlqIo-A0UmAvki-2QH5mqfwcvCxUiSlEhVNxtioWunb9axF1ioG~41MwYML6pKxclyx8Mq~cxvEXkz0ldvo5VjlsAyX1GnAhpaxsCkHi0Eb9in8wnqtYkfVuk~j6ooWhLf~g7TgDGEaZsbsUcnm2WybW-BcA-PNanaT2FN48~zSYL8-0FTwoRGpgG5MGbtkGPzQN7vuhDsQ3DFHFYNl7UllKm3I7nGFW-ial1Y~AqiwDhD5eKA0c~s5UIPapxImZQgxLNDD3aO-a8ePEqqyc5z1fYNQIChDirt-gkpFvYTNLbJwOb8jHKc2d5KFKeWRDkTXXh1KR27BwXgSjEg__",
		image2:
			"https://s3-alpha-sig.figma.com/img/a95b/553d/07b7f8faa305d5e35585d3a62a1ffdd3?Expires=1708905600&Key-Pair-Id=APKAQ4GOSFWCVNEHN3O4&Signature=TPuYorwotzw5LdL~N-zqbyHZOzvIqAyVvC4SntCNrY53oJigDlOEsgDDF-FPSgOMoqIYwsNvK1VOIT1udKu92q-vDl9Tml6XatSbZ-hZWEQmj4dJHpNyfYRdyqcGTqApj1J4qayKi~XXx-WmYtJA-A9BwFVNYwXRQTP9p71np1NYjE5pGwTSAhD5q1xkEZeS6c3zbPO8lDFWGHrWRRiXtjkklRLvt7gL1Vf663jc2qbWZ6Djzn2eC6sSgUSnsyPAdYfUflowxTHFgxpeqwSFwTWHzgOryTtRBor-2yMIHA-SgvZpi4PFS03HCED3c3ifDYAm28AITeJmAhQG6PovsQ__",
	},
	{
		name: "اسپرسوساز نون مدل CM540 3D-GS",
		price: 18000,
		description: "product 4",
		badge: "تخفیف ویژه",
		discount: 10,
		image1:
			"https://s3-alpha-sig.figma.com/img/9cdd/cdda/5c9567f323a8d9d1b5ee609f833964b0?Expires=1708905600&Key-Pair-Id=APKAQ4GOSFWCVNEHN3O4&Signature=g80ILlqIo-A0UmAvki-2QH5mqfwcvCxUiSlEhVNxtioWunb9axF1ioG~41MwYML6pKxclyx8Mq~cxvEXkz0ldvo5VjlsAyX1GnAhpaxsCkHi0Eb9in8wnqtYkfVuk~j6ooWhLf~g7TgDGEaZsbsUcnm2WybW-BcA-PNanaT2FN48~zSYL8-0FTwoRGpgG5MGbtkGPzQN7vuhDsQ3DFHFYNl7UllKm3I7nGFW-ial1Y~AqiwDhD5eKA0c~s5UIPapxImZQgxLNDD3aO-a8ePEqqyc5z1fYNQIChDirt-gkpFvYTNLbJwOb8jHKc2d5KFKeWRDkTXXh1KR27BwXgSjEg__",
		image2:
			"https://s3-alpha-sig.figma.com/img/a95b/553d/07b7f8faa305d5e35585d3a62a1ffdd3?Expires=1708905600&Key-Pair-Id=APKAQ4GOSFWCVNEHN3O4&Signature=TPuYorwotzw5LdL~N-zqbyHZOzvIqAyVvC4SntCNrY53oJigDlOEsgDDF-FPSgOMoqIYwsNvK1VOIT1udKu92q-vDl9Tml6XatSbZ-hZWEQmj4dJHpNyfYRdyqcGTqApj1J4qayKi~XXx-WmYtJA-A9BwFVNYwXRQTP9p71np1NYjE5pGwTSAhD5q1xkEZeS6c3zbPO8lDFWGHrWRRiXtjkklRLvt7gL1Vf663jc2qbWZ6Djzn2eC6sSgUSnsyPAdYfUflowxTHFgxpeqwSFwTWHzgOryTtRBor-2yMIHA-SgvZpi4PFS03HCED3c3ifDYAm28AITeJmAhQG6PovsQ__",
	},
	{
		name: "اسپرسوساز نون مدل CM540 3D-GS",
		price: 18000,
		description: "product 5",
		badge: "10%",
		discount: 10,
		image1:
			"https://s3-alpha-sig.figma.com/img/9cdd/cdda/5c9567f323a8d9d1b5ee609f833964b0?Expires=1708905600&Key-Pair-Id=APKAQ4GOSFWCVNEHN3O4&Signature=g80ILlqIo-A0UmAvki-2QH5mqfwcvCxUiSlEhVNxtioWunb9axF1ioG~41MwYML6pKxclyx8Mq~cxvEXkz0ldvo5VjlsAyX1GnAhpaxsCkHi0Eb9in8wnqtYkfVuk~j6ooWhLf~g7TgDGEaZsbsUcnm2WybW-BcA-PNanaT2FN48~zSYL8-0FTwoRGpgG5MGbtkGPzQN7vuhDsQ3DFHFYNl7UllKm3I7nGFW-ial1Y~AqiwDhD5eKA0c~s5UIPapxImZQgxLNDD3aO-a8ePEqqyc5z1fYNQIChDirt-gkpFvYTNLbJwOb8jHKc2d5KFKeWRDkTXXh1KR27BwXgSjEg__",
		image2:
			"https://s3-alpha-sig.figma.com/img/a95b/553d/07b7f8faa305d5e35585d3a62a1ffdd3?Expires=1708905600&Key-Pair-Id=APKAQ4GOSFWCVNEHN3O4&Signature=TPuYorwotzw5LdL~N-zqbyHZOzvIqAyVvC4SntCNrY53oJigDlOEsgDDF-FPSgOMoqIYwsNvK1VOIT1udKu92q-vDl9Tml6XatSbZ-hZWEQmj4dJHpNyfYRdyqcGTqApj1J4qayKi~XXx-WmYtJA-A9BwFVNYwXRQTP9p71np1NYjE5pGwTSAhD5q1xkEZeS6c3zbPO8lDFWGHrWRRiXtjkklRLvt7gL1Vf663jc2qbWZ6Djzn2eC6sSgUSnsyPAdYfUflowxTHFgxpeqwSFwTWHzgOryTtRBor-2yMIHA-SgvZpi4PFS03HCED3c3ifDYAm28AITeJmAhQG6PovsQ__",
	},
	{
		name: "اسپرسوساز نون مدل CM540 3D-GS",
		price: 18000,
		description: "product 6",
		badge: "جدید",
		discount: 0,
		image1:
			"https://s3-alpha-sig.figma.com/img/9cdd/cdda/5c9567f323a8d9d1b5ee609f833964b0?Expires=1708905600&Key-Pair-Id=APKAQ4GOSFWCVNEHN3O4&Signature=g80ILlqIo-A0UmAvki-2QH5mqfwcvCxUiSlEhVNxtioWunb9axF1ioG~41MwYML6pKxclyx8Mq~cxvEXkz0ldvo5VjlsAyX1GnAhpaxsCkHi0Eb9in8wnqtYkfVuk~j6ooWhLf~g7TgDGEaZsbsUcnm2WybW-BcA-PNanaT2FN48~zSYL8-0FTwoRGpgG5MGbtkGPzQN7vuhDsQ3DFHFYNl7UllKm3I7nGFW-ial1Y~AqiwDhD5eKA0c~s5UIPapxImZQgxLNDD3aO-a8ePEqqyc5z1fYNQIChDirt-gkpFvYTNLbJwOb8jHKc2d5KFKeWRDkTXXh1KR27BwXgSjEg__",
		image2:
			"https://s3-alpha-sig.figma.com/img/a95b/553d/07b7f8faa305d5e35585d3a62a1ffdd3?Expires=1708905600&Key-Pair-Id=APKAQ4GOSFWCVNEHN3O4&Signature=TPuYorwotzw5LdL~N-zqbyHZOzvIqAyVvC4SntCNrY53oJigDlOEsgDDF-FPSgOMoqIYwsNvK1VOIT1udKu92q-vDl9Tml6XatSbZ-hZWEQmj4dJHpNyfYRdyqcGTqApj1J4qayKi~XXx-WmYtJA-A9BwFVNYwXRQTP9p71np1NYjE5pGwTSAhD5q1xkEZeS6c3zbPO8lDFWGHrWRRiXtjkklRLvt7gL1Vf663jc2qbWZ6Djzn2eC6sSgUSnsyPAdYfUflowxTHFgxpeqwSFwTWHzgOryTtRBor-2yMIHA-SgvZpi4PFS03HCED3c3ifDYAm28AITeJmAhQG6PovsQ__",
	},
	{
		name: "اسپرسوساز نون مدل CM540 3D-GS",
		price: 18000,
		description: "product 7",
		badge: "تخفیف ویژه",
		discount: 10,
		image1:
			"https://s3-alpha-sig.figma.com/img/9cdd/cdda/5c9567f323a8d9d1b5ee609f833964b0?Expires=1708905600&Key-Pair-Id=APKAQ4GOSFWCVNEHN3O4&Signature=g80ILlqIo-A0UmAvki-2QH5mqfwcvCxUiSlEhVNxtioWunb9axF1ioG~41MwYML6pKxclyx8Mq~cxvEXkz0ldvo5VjlsAyX1GnAhpaxsCkHi0Eb9in8wnqtYkfVuk~j6ooWhLf~g7TgDGEaZsbsUcnm2WybW-BcA-PNanaT2FN48~zSYL8-0FTwoRGpgG5MGbtkGPzQN7vuhDsQ3DFHFYNl7UllKm3I7nGFW-ial1Y~AqiwDhD5eKA0c~s5UIPapxImZQgxLNDD3aO-a8ePEqqyc5z1fYNQIChDirt-gkpFvYTNLbJwOb8jHKc2d5KFKeWRDkTXXh1KR27BwXgSjEg__",
		image2:
			"https://s3-alpha-sig.figma.com/img/a95b/553d/07b7f8faa305d5e35585d3a62a1ffdd3?Expires=1708905600&Key-Pair-Id=APKAQ4GOSFWCVNEHN3O4&Signature=TPuYorwotzw5LdL~N-zqbyHZOzvIqAyVvC4SntCNrY53oJigDlOEsgDDF-FPSgOMoqIYwsNvK1VOIT1udKu92q-vDl9Tml6XatSbZ-hZWEQmj4dJHpNyfYRdyqcGTqApj1J4qayKi~XXx-WmYtJA-A9BwFVNYwXRQTP9p71np1NYjE5pGwTSAhD5q1xkEZeS6c3zbPO8lDFWGHrWRRiXtjkklRLvt7gL1Vf663jc2qbWZ6Djzn2eC6sSgUSnsyPAdYfUflowxTHFgxpeqwSFwTWHzgOryTtRBor-2yMIHA-SgvZpi4PFS03HCED3c3ifDYAm28AITeJmAhQG6PovsQ__",
	},
	{
		name: "اسپرسوساز نون مدل CM540 3D-GS",
		price: 18000,
		description: "product 8",
		badge: "10%",
		discount: 10,
		image1:
			"https://s3-alpha-sig.figma.com/img/9cdd/cdda/5c9567f323a8d9d1b5ee609f833964b0?Expires=1708905600&Key-Pair-Id=APKAQ4GOSFWCVNEHN3O4&Signature=g80ILlqIo-A0UmAvki-2QH5mqfwcvCxUiSlEhVNxtioWunb9axF1ioG~41MwYML6pKxclyx8Mq~cxvEXkz0ldvo5VjlsAyX1GnAhpaxsCkHi0Eb9in8wnqtYkfVuk~j6ooWhLf~g7TgDGEaZsbsUcnm2WybW-BcA-PNanaT2FN48~zSYL8-0FTwoRGpgG5MGbtkGPzQN7vuhDsQ3DFHFYNl7UllKm3I7nGFW-ial1Y~AqiwDhD5eKA0c~s5UIPapxImZQgxLNDD3aO-a8ePEqqyc5z1fYNQIChDirt-gkpFvYTNLbJwOb8jHKc2d5KFKeWRDkTXXh1KR27BwXgSjEg__",
		image2:
			"https://s3-alpha-sig.figma.com/img/a95b/553d/07b7f8faa305d5e35585d3a62a1ffdd3?Expires=1708905600&Key-Pair-Id=APKAQ4GOSFWCVNEHN3O4&Signature=TPuYorwotzw5LdL~N-zqbyHZOzvIqAyVvC4SntCNrY53oJigDlOEsgDDF-FPSgOMoqIYwsNvK1VOIT1udKu92q-vDl9Tml6XatSbZ-hZWEQmj4dJHpNyfYRdyqcGTqApj1J4qayKi~XXx-WmYtJA-A9BwFVNYwXRQTP9p71np1NYjE5pGwTSAhD5q1xkEZeS6c3zbPO8lDFWGHrWRRiXtjkklRLvt7gL1Vf663jc2qbWZ6Djzn2eC6sSgUSnsyPAdYfUflowxTHFgxpeqwSFwTWHzgOryTtRBor-2yMIHA-SgvZpi4PFS03HCED3c3ifDYAm28AITeJmAhQG6PovsQ__",
	},
	{
		name: "اسپرسوساز نون مدل CM540 3D-GS",
		price: 18000,
		description: "product 9",
		badge: "جدید",
		discount: 0,
		image1:
			"https://s3-alpha-sig.figma.com/img/9cdd/cdda/5c9567f323a8d9d1b5ee609f833964b0?Expires=1708905600&Key-Pair-Id=APKAQ4GOSFWCVNEHN3O4&Signature=g80ILlqIo-A0UmAvki-2QH5mqfwcvCxUiSlEhVNxtioWunb9axF1ioG~41MwYML6pKxclyx8Mq~cxvEXkz0ldvo5VjlsAyX1GnAhpaxsCkHi0Eb9in8wnqtYkfVuk~j6ooWhLf~g7TgDGEaZsbsUcnm2WybW-BcA-PNanaT2FN48~zSYL8-0FTwoRGpgG5MGbtkGPzQN7vuhDsQ3DFHFYNl7UllKm3I7nGFW-ial1Y~AqiwDhD5eKA0c~s5UIPapxImZQgxLNDD3aO-a8ePEqqyc5z1fYNQIChDirt-gkpFvYTNLbJwOb8jHKc2d5KFKeWRDkTXXh1KR27BwXgSjEg__",
		image2:
			"https://s3-alpha-sig.figma.com/img/a95b/553d/07b7f8faa305d5e35585d3a62a1ffdd3?Expires=1708905600&Key-Pair-Id=APKAQ4GOSFWCVNEHN3O4&Signature=TPuYorwotzw5LdL~N-zqbyHZOzvIqAyVvC4SntCNrY53oJigDlOEsgDDF-FPSgOMoqIYwsNvK1VOIT1udKu92q-vDl9Tml6XatSbZ-hZWEQmj4dJHpNyfYRdyqcGTqApj1J4qayKi~XXx-WmYtJA-A9BwFVNYwXRQTP9p71np1NYjE5pGwTSAhD5q1xkEZeS6c3zbPO8lDFWGHrWRRiXtjkklRLvt7gL1Vf663jc2qbWZ6Djzn2eC6sSgUSnsyPAdYfUflowxTHFgxpeqwSFwTWHzgOryTtRBor-2yMIHA-SgvZpi4PFS03HCED3c3ifDYAm28AITeJmAhQG6PovsQ__",
	},
	{
		name: "اسپرسوساز نون مدل CM540 3D-GS",
		price: 18000,
		description: "product 1",
		badge: "تخفیف ویژه",
		discount: 10,
		image1:
			"https://s3-alpha-sig.figma.com/img/9cdd/cdda/5c9567f323a8d9d1b5ee609f833964b0?Expires=1708905600&Key-Pair-Id=APKAQ4GOSFWCVNEHN3O4&Signature=g80ILlqIo-A0UmAvki-2QH5mqfwcvCxUiSlEhVNxtioWunb9axF1ioG~41MwYML6pKxclyx8Mq~cxvEXkz0ldvo5VjlsAyX1GnAhpaxsCkHi0Eb9in8wnqtYkfVuk~j6ooWhLf~g7TgDGEaZsbsUcnm2WybW-BcA-PNanaT2FN48~zSYL8-0FTwoRGpgG5MGbtkGPzQN7vuhDsQ3DFHFYNl7UllKm3I7nGFW-ial1Y~AqiwDhD5eKA0c~s5UIPapxImZQgxLNDD3aO-a8ePEqqyc5z1fYNQIChDirt-gkpFvYTNLbJwOb8jHKc2d5KFKeWRDkTXXh1KR27BwXgSjEg__",
		image2:
			"https://s3-alpha-sig.figma.com/img/a95b/553d/07b7f8faa305d5e35585d3a62a1ffdd3?Expires=1708905600&Key-Pair-Id=APKAQ4GOSFWCVNEHN3O4&Signature=TPuYorwotzw5LdL~N-zqbyHZOzvIqAyVvC4SntCNrY53oJigDlOEsgDDF-FPSgOMoqIYwsNvK1VOIT1udKu92q-vDl9Tml6XatSbZ-hZWEQmj4dJHpNyfYRdyqcGTqApj1J4qayKi~XXx-WmYtJA-A9BwFVNYwXRQTP9p71np1NYjE5pGwTSAhD5q1xkEZeS6c3zbPO8lDFWGHrWRRiXtjkklRLvt7gL1Vf663jc2qbWZ6Djzn2eC6sSgUSnsyPAdYfUflowxTHFgxpeqwSFwTWHzgOryTtRBor-2yMIHA-SgvZpi4PFS03HCED3c3ifDYAm28AITeJmAhQG6PovsQ__",
	},
	{
		name: "اسپرسوساز نون مدل CM540 3D-GS",
		price: 18000,
		description: "product 2",
		badge: "10%",
		discount: 10,
		image1:
			"https://s3-alpha-sig.figma.com/img/9cdd/cdda/5c9567f323a8d9d1b5ee609f833964b0?Expires=1708905600&Key-Pair-Id=APKAQ4GOSFWCVNEHN3O4&Signature=g80ILlqIo-A0UmAvki-2QH5mqfwcvCxUiSlEhVNxtioWunb9axF1ioG~41MwYML6pKxclyx8Mq~cxvEXkz0ldvo5VjlsAyX1GnAhpaxsCkHi0Eb9in8wnqtYkfVuk~j6ooWhLf~g7TgDGEaZsbsUcnm2WybW-BcA-PNanaT2FN48~zSYL8-0FTwoRGpgG5MGbtkGPzQN7vuhDsQ3DFHFYNl7UllKm3I7nGFW-ial1Y~AqiwDhD5eKA0c~s5UIPapxImZQgxLNDD3aO-a8ePEqqyc5z1fYNQIChDirt-gkpFvYTNLbJwOb8jHKc2d5KFKeWRDkTXXh1KR27BwXgSjEg__",
		image2:
			"https://s3-alpha-sig.figma.com/img/a95b/553d/07b7f8faa305d5e35585d3a62a1ffdd3?Expires=1708905600&Key-Pair-Id=APKAQ4GOSFWCVNEHN3O4&Signature=TPuYorwotzw5LdL~N-zqbyHZOzvIqAyVvC4SntCNrY53oJigDlOEsgDDF-FPSgOMoqIYwsNvK1VOIT1udKu92q-vDl9Tml6XatSbZ-hZWEQmj4dJHpNyfYRdyqcGTqApj1J4qayKi~XXx-WmYtJA-A9BwFVNYwXRQTP9p71np1NYjE5pGwTSAhD5q1xkEZeS6c3zbPO8lDFWGHrWRRiXtjkklRLvt7gL1Vf663jc2qbWZ6Djzn2eC6sSgUSnsyPAdYfUflowxTHFgxpeqwSFwTWHzgOryTtRBor-2yMIHA-SgvZpi4PFS03HCED3c3ifDYAm28AITeJmAhQG6PovsQ__",
	},
	{
		name: "اسپرسوساز نون مدل CM540 3D-GS",
		price: 18000,
		description: "product 3",
		badge: "جدید",
		discount: 0,
		image1:
			"https://s3-alpha-sig.figma.com/img/9cdd/cdda/5c9567f323a8d9d1b5ee609f833964b0?Expires=1708905600&Key-Pair-Id=APKAQ4GOSFWCVNEHN3O4&Signature=g80ILlqIo-A0UmAvki-2QH5mqfwcvCxUiSlEhVNxtioWunb9axF1ioG~41MwYML6pKxclyx8Mq~cxvEXkz0ldvo5VjlsAyX1GnAhpaxsCkHi0Eb9in8wnqtYkfVuk~j6ooWhLf~g7TgDGEaZsbsUcnm2WybW-BcA-PNanaT2FN48~zSYL8-0FTwoRGpgG5MGbtkGPzQN7vuhDsQ3DFHFYNl7UllKm3I7nGFW-ial1Y~AqiwDhD5eKA0c~s5UIPapxImZQgxLNDD3aO-a8ePEqqyc5z1fYNQIChDirt-gkpFvYTNLbJwOb8jHKc2d5KFKeWRDkTXXh1KR27BwXgSjEg__",
		image2:
			"https://s3-alpha-sig.figma.com/img/a95b/553d/07b7f8faa305d5e35585d3a62a1ffdd3?Expires=1708905600&Key-Pair-Id=APKAQ4GOSFWCVNEHN3O4&Signature=TPuYorwotzw5LdL~N-zqbyHZOzvIqAyVvC4SntCNrY53oJigDlOEsgDDF-FPSgOMoqIYwsNvK1VOIT1udKu92q-vDl9Tml6XatSbZ-hZWEQmj4dJHpNyfYRdyqcGTqApj1J4qayKi~XXx-WmYtJA-A9BwFVNYwXRQTP9p71np1NYjE5pGwTSAhD5q1xkEZeS6c3zbPO8lDFWGHrWRRiXtjkklRLvt7gL1Vf663jc2qbWZ6Djzn2eC6sSgUSnsyPAdYfUflowxTHFgxpeqwSFwTWHzgOryTtRBor-2yMIHA-SgvZpi4PFS03HCED3c3ifDYAm28AITeJmAhQG6PovsQ__",
	},
	{
		name: "اسپرسوساز نون مدل CM540 3D-GS",
		price: 18000,
		description: "product 4",
		badge: "تخفیف ویژه",
		discount: 10,
		image1:
			"https://s3-alpha-sig.figma.com/img/9cdd/cdda/5c9567f323a8d9d1b5ee609f833964b0?Expires=1708905600&Key-Pair-Id=APKAQ4GOSFWCVNEHN3O4&Signature=g80ILlqIo-A0UmAvki-2QH5mqfwcvCxUiSlEhVNxtioWunb9axF1ioG~41MwYML6pKxclyx8Mq~cxvEXkz0ldvo5VjlsAyX1GnAhpaxsCkHi0Eb9in8wnqtYkfVuk~j6ooWhLf~g7TgDGEaZsbsUcnm2WybW-BcA-PNanaT2FN48~zSYL8-0FTwoRGpgG5MGbtkGPzQN7vuhDsQ3DFHFYNl7UllKm3I7nGFW-ial1Y~AqiwDhD5eKA0c~s5UIPapxImZQgxLNDD3aO-a8ePEqqyc5z1fYNQIChDirt-gkpFvYTNLbJwOb8jHKc2d5KFKeWRDkTXXh1KR27BwXgSjEg__",
		image2:
			"https://s3-alpha-sig.figma.com/img/a95b/553d/07b7f8faa305d5e35585d3a62a1ffdd3?Expires=1708905600&Key-Pair-Id=APKAQ4GOSFWCVNEHN3O4&Signature=TPuYorwotzw5LdL~N-zqbyHZOzvIqAyVvC4SntCNrY53oJigDlOEsgDDF-FPSgOMoqIYwsNvK1VOIT1udKu92q-vDl9Tml6XatSbZ-hZWEQmj4dJHpNyfYRdyqcGTqApj1J4qayKi~XXx-WmYtJA-A9BwFVNYwXRQTP9p71np1NYjE5pGwTSAhD5q1xkEZeS6c3zbPO8lDFWGHrWRRiXtjkklRLvt7gL1Vf663jc2qbWZ6Djzn2eC6sSgUSnsyPAdYfUflowxTHFgxpeqwSFwTWHzgOryTtRBor-2yMIHA-SgvZpi4PFS03HCED3c3ifDYAm28AITeJmAhQG6PovsQ__",
	},
	{
		name: "اسپرسوساز نون مدل CM540 3D-GS",
		price: 18000,
		description: "product 5",
		badge: "10%",
		discount: 10,
		image1:
			"https://s3-alpha-sig.figma.com/img/9cdd/cdda/5c9567f323a8d9d1b5ee609f833964b0?Expires=1708905600&Key-Pair-Id=APKAQ4GOSFWCVNEHN3O4&Signature=g80ILlqIo-A0UmAvki-2QH5mqfwcvCxUiSlEhVNxtioWunb9axF1ioG~41MwYML6pKxclyx8Mq~cxvEXkz0ldvo5VjlsAyX1GnAhpaxsCkHi0Eb9in8wnqtYkfVuk~j6ooWhLf~g7TgDGEaZsbsUcnm2WybW-BcA-PNanaT2FN48~zSYL8-0FTwoRGpgG5MGbtkGPzQN7vuhDsQ3DFHFYNl7UllKm3I7nGFW-ial1Y~AqiwDhD5eKA0c~s5UIPapxImZQgxLNDD3aO-a8ePEqqyc5z1fYNQIChDirt-gkpFvYTNLbJwOb8jHKc2d5KFKeWRDkTXXh1KR27BwXgSjEg__",
		image2:
			"https://s3-alpha-sig.figma.com/img/a95b/553d/07b7f8faa305d5e35585d3a62a1ffdd3?Expires=1708905600&Key-Pair-Id=APKAQ4GOSFWCVNEHN3O4&Signature=TPuYorwotzw5LdL~N-zqbyHZOzvIqAyVvC4SntCNrY53oJigDlOEsgDDF-FPSgOMoqIYwsNvK1VOIT1udKu92q-vDl9Tml6XatSbZ-hZWEQmj4dJHpNyfYRdyqcGTqApj1J4qayKi~XXx-WmYtJA-A9BwFVNYwXRQTP9p71np1NYjE5pGwTSAhD5q1xkEZeS6c3zbPO8lDFWGHrWRRiXtjkklRLvt7gL1Vf663jc2qbWZ6Djzn2eC6sSgUSnsyPAdYfUflowxTHFgxpeqwSFwTWHzgOryTtRBor-2yMIHA-SgvZpi4PFS03HCED3c3ifDYAm28AITeJmAhQG6PovsQ__",
	},
	{
		name: "اسپرسوساز نون مدل CM540 3D-GS",
		price: 18000,
		description: "product 6",
		badge: "جدید",
		discount: 0,
		image1:
			"https://s3-alpha-sig.figma.com/img/9cdd/cdda/5c9567f323a8d9d1b5ee609f833964b0?Expires=1708905600&Key-Pair-Id=APKAQ4GOSFWCVNEHN3O4&Signature=g80ILlqIo-A0UmAvki-2QH5mqfwcvCxUiSlEhVNxtioWunb9axF1ioG~41MwYML6pKxclyx8Mq~cxvEXkz0ldvo5VjlsAyX1GnAhpaxsCkHi0Eb9in8wnqtYkfVuk~j6ooWhLf~g7TgDGEaZsbsUcnm2WybW-BcA-PNanaT2FN48~zSYL8-0FTwoRGpgG5MGbtkGPzQN7vuhDsQ3DFHFYNl7UllKm3I7nGFW-ial1Y~AqiwDhD5eKA0c~s5UIPapxImZQgxLNDD3aO-a8ePEqqyc5z1fYNQIChDirt-gkpFvYTNLbJwOb8jHKc2d5KFKeWRDkTXXh1KR27BwXgSjEg__",
		image2:
			"https://s3-alpha-sig.figma.com/img/a95b/553d/07b7f8faa305d5e35585d3a62a1ffdd3?Expires=1708905600&Key-Pair-Id=APKAQ4GOSFWCVNEHN3O4&Signature=TPuYorwotzw5LdL~N-zqbyHZOzvIqAyVvC4SntCNrY53oJigDlOEsgDDF-FPSgOMoqIYwsNvK1VOIT1udKu92q-vDl9Tml6XatSbZ-hZWEQmj4dJHpNyfYRdyqcGTqApj1J4qayKi~XXx-WmYtJA-A9BwFVNYwXRQTP9p71np1NYjE5pGwTSAhD5q1xkEZeS6c3zbPO8lDFWGHrWRRiXtjkklRLvt7gL1Vf663jc2qbWZ6Djzn2eC6sSgUSnsyPAdYfUflowxTHFgxpeqwSFwTWHzgOryTtRBor-2yMIHA-SgvZpi4PFS03HCED3c3ifDYAm28AITeJmAhQG6PovsQ__",
	},
	{
		name: "اسپرسوساز نون مدل CM540 3D-GS",
		price: 18000,
		description: "product 7",
		badge: "تخفیف ویژه",
		discount: 10,
		image1:
			"https://s3-alpha-sig.figma.com/img/9cdd/cdda/5c9567f323a8d9d1b5ee609f833964b0?Expires=1708905600&Key-Pair-Id=APKAQ4GOSFWCVNEHN3O4&Signature=g80ILlqIo-A0UmAvki-2QH5mqfwcvCxUiSlEhVNxtioWunb9axF1ioG~41MwYML6pKxclyx8Mq~cxvEXkz0ldvo5VjlsAyX1GnAhpaxsCkHi0Eb9in8wnqtYkfVuk~j6ooWhLf~g7TgDGEaZsbsUcnm2WybW-BcA-PNanaT2FN48~zSYL8-0FTwoRGpgG5MGbtkGPzQN7vuhDsQ3DFHFYNl7UllKm3I7nGFW-ial1Y~AqiwDhD5eKA0c~s5UIPapxImZQgxLNDD3aO-a8ePEqqyc5z1fYNQIChDirt-gkpFvYTNLbJwOb8jHKc2d5KFKeWRDkTXXh1KR27BwXgSjEg__",
		image2:
			"https://s3-alpha-sig.figma.com/img/a95b/553d/07b7f8faa305d5e35585d3a62a1ffdd3?Expires=1708905600&Key-Pair-Id=APKAQ4GOSFWCVNEHN3O4&Signature=TPuYorwotzw5LdL~N-zqbyHZOzvIqAyVvC4SntCNrY53oJigDlOEsgDDF-FPSgOMoqIYwsNvK1VOIT1udKu92q-vDl9Tml6XatSbZ-hZWEQmj4dJHpNyfYRdyqcGTqApj1J4qayKi~XXx-WmYtJA-A9BwFVNYwXRQTP9p71np1NYjE5pGwTSAhD5q1xkEZeS6c3zbPO8lDFWGHrWRRiXtjkklRLvt7gL1Vf663jc2qbWZ6Djzn2eC6sSgUSnsyPAdYfUflowxTHFgxpeqwSFwTWHzgOryTtRBor-2yMIHA-SgvZpi4PFS03HCED3c3ifDYAm28AITeJmAhQG6PovsQ__",
	},
	{
		name: "اسپرسوساز نون مدل CM540 3D-GS",
		price: 18000,
		description: "product 8",
		badge: "10%",
		discount: 10,
		image1:
			"https://s3-alpha-sig.figma.com/img/9cdd/cdda/5c9567f323a8d9d1b5ee609f833964b0?Expires=1708905600&Key-Pair-Id=APKAQ4GOSFWCVNEHN3O4&Signature=g80ILlqIo-A0UmAvki-2QH5mqfwcvCxUiSlEhVNxtioWunb9axF1ioG~41MwYML6pKxclyx8Mq~cxvEXkz0ldvo5VjlsAyX1GnAhpaxsCkHi0Eb9in8wnqtYkfVuk~j6ooWhLf~g7TgDGEaZsbsUcnm2WybW-BcA-PNanaT2FN48~zSYL8-0FTwoRGpgG5MGbtkGPzQN7vuhDsQ3DFHFYNl7UllKm3I7nGFW-ial1Y~AqiwDhD5eKA0c~s5UIPapxImZQgxLNDD3aO-a8ePEqqyc5z1fYNQIChDirt-gkpFvYTNLbJwOb8jHKc2d5KFKeWRDkTXXh1KR27BwXgSjEg__",
		image2:
			"https://s3-alpha-sig.figma.com/img/a95b/553d/07b7f8faa305d5e35585d3a62a1ffdd3?Expires=1708905600&Key-Pair-Id=APKAQ4GOSFWCVNEHN3O4&Signature=TPuYorwotzw5LdL~N-zqbyHZOzvIqAyVvC4SntCNrY53oJigDlOEsgDDF-FPSgOMoqIYwsNvK1VOIT1udKu92q-vDl9Tml6XatSbZ-hZWEQmj4dJHpNyfYRdyqcGTqApj1J4qayKi~XXx-WmYtJA-A9BwFVNYwXRQTP9p71np1NYjE5pGwTSAhD5q1xkEZeS6c3zbPO8lDFWGHrWRRiXtjkklRLvt7gL1Vf663jc2qbWZ6Djzn2eC6sSgUSnsyPAdYfUflowxTHFgxpeqwSFwTWHzgOryTtRBor-2yMIHA-SgvZpi4PFS03HCED3c3ifDYAm28AITeJmAhQG6PovsQ__",
	},
	{
		name: "اسپرسوساز نون مدل CM540 3D-GS",
		price: 18000,
		description: "product 9",
		badge: "جدید",
		discount: 0,
		image1:
			"https://s3-alpha-sig.figma.com/img/9cdd/cdda/5c9567f323a8d9d1b5ee609f833964b0?Expires=1708905600&Key-Pair-Id=APKAQ4GOSFWCVNEHN3O4&Signature=g80ILlqIo-A0UmAvki-2QH5mqfwcvCxUiSlEhVNxtioWunb9axF1ioG~41MwYML6pKxclyx8Mq~cxvEXkz0ldvo5VjlsAyX1GnAhpaxsCkHi0Eb9in8wnqtYkfVuk~j6ooWhLf~g7TgDGEaZsbsUcnm2WybW-BcA-PNanaT2FN48~zSYL8-0FTwoRGpgG5MGbtkGPzQN7vuhDsQ3DFHFYNl7UllKm3I7nGFW-ial1Y~AqiwDhD5eKA0c~s5UIPapxImZQgxLNDD3aO-a8ePEqqyc5z1fYNQIChDirt-gkpFvYTNLbJwOb8jHKc2d5KFKeWRDkTXXh1KR27BwXgSjEg__",
		image2:
			"https://s3-alpha-sig.figma.com/img/a95b/553d/07b7f8faa305d5e35585d3a62a1ffdd3?Expires=1708905600&Key-Pair-Id=APKAQ4GOSFWCVNEHN3O4&Signature=TPuYorwotzw5LdL~N-zqbyHZOzvIqAyVvC4SntCNrY53oJigDlOEsgDDF-FPSgOMoqIYwsNvK1VOIT1udKu92q-vDl9Tml6XatSbZ-hZWEQmj4dJHpNyfYRdyqcGTqApj1J4qayKi~XXx-WmYtJA-A9BwFVNYwXRQTP9p71np1NYjE5pGwTSAhD5q1xkEZeS6c3zbPO8lDFWGHrWRRiXtjkklRLvt7gL1Vf663jc2qbWZ6Djzn2eC6sSgUSnsyPAdYfUflowxTHFgxpeqwSFwTWHzgOryTtRBor-2yMIHA-SgvZpi4PFS03HCED3c3ifDYAm28AITeJmAhQG6PovsQ__",
	},
];
