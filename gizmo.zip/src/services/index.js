export const baseUrl = "https://gn02.liara.run";
