class Colors {
	static blue_light = "#8ECDDD";
	static blue = "#22668D";
	static blue_dark = "#252B48";
	static orange = "#FFCC70";
	static yellow = "#FFFADD";
}

export default Colors;
